
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'torrinlisi',
  applicationName: 'rsvp',
  appUid: 'FJMjZNdlwlKbR6PdRj',
  orgUid: '2d6b4ba5-5abb-4b7f-a9f3-25ad1d4b4dfc',
  deploymentUid: 'b3fda3ef-f86c-4d63-8cd6-615c3a2d6007',
  serviceName: 'rsvp-service',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'yan',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '4.5.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'validate-rsvp-yan', timeout: 6 };

try {
  const userHandler = require('./validate-rsvp/index.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}