
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'torrinlisi',
  applicationName: 'rsvp',
  appUid: 'FJMjZNdlwlKbR6PdRj',
  orgUid: '2d6b4ba5-5abb-4b7f-a9f3-25ad1d4b4dfc',
  deploymentUid: 'c14300da-630e-48af-a431-367eadfe27f2',
  serviceName: 'rsvp-service',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '4.5.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'validate-rsvp-dev', timeout: 6 };

try {
  const userHandler = require('./validate-rsvp/index.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}